package com.example.inventoryapp_matthewcillo_project2;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

// Main inventory screen. Displays every item in a grid-style list and lets
// the user add, edit, or delete items. Also requests permission to send SMS
// alerts the first time this screen opens, so low-stock notifications can work
// later on the Add/Edit screen. If the user denies permission, the rest of the
// app keeps working normally, it just skips sending text alerts.
public class InventoryActivity extends AppCompatActivity implements InventoryAdapter.OnItemActionListener {

    private DatabaseHelper databaseHelper;
    private InventoryAdapter adapter;
    private ActivityResultLauncher<String> smsPermissionLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        databaseHelper = new DatabaseHelper(this);

        RecyclerView recyclerView = findViewById(R.id.inventoryRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        Button addItemButton = findViewById(R.id.addItemButton);
        addItemButton.setOnClickListener(v -> {
            Intent intent = new Intent(InventoryActivity.this, AddItemActivity.class);
            startActivity(intent);
        });

        List<InventoryItem> items = databaseHelper.getAllItems();
        adapter = new InventoryAdapter(items, this);
        recyclerView.setAdapter(adapter);

        setUpSmsPermissionLauncher();
        requestSmsPermissionIfNeeded();
    }

    // Registers the callback that runs after the user responds to the permission dialog.
    private void setUpSmsPermissionLauncher() {
        smsPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                isGranted -> {
                    if (isGranted) {
                        Toast.makeText(this, "SMS alerts are now enabled.", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, getString(R.string.sms_permission_denied), Toast.LENGTH_LONG).show();
                    }
                }
        );
    }

    // Checks whether SMS permission is already granted. If not, asks the user for it.
    // This only prompts the user if permission has not already been granted or denied
    // in a way that Android is still willing to ask about again.
    private void requestSmsPermissionIfNeeded() {
        boolean alreadyGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;

        if (!alreadyGranted) {
            smsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshItemList();
    }

    // Reloads the item list from the database and updates the grid on screen.
    private void refreshItemList() {
        List<InventoryItem> items = databaseHelper.getAllItems();
        adapter.updateItems(items);
    }

    @Override
    public void onEditClicked(InventoryItem item) {
        Intent intent = new Intent(InventoryActivity.this, AddItemActivity.class);
        intent.putExtra(AddItemActivity.EXTRA_ITEM_ID, item.getId());
        startActivity(intent);
    }

    @Override
    public void onDeleteClicked(InventoryItem item) {
        databaseHelper.deleteItem(item.getId());
        refreshItemList();
    }
}