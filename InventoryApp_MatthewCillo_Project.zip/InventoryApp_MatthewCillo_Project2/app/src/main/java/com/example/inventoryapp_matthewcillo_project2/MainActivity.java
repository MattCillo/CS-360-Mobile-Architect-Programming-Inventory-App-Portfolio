package com.example.inventoryapp_matthewcillo_project2;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText usernameInput;
    private EditText passwordInput;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        databaseHelper = new DatabaseHelper(this);

        usernameInput = findViewById(R.id.usernameInput);
        passwordInput = findViewById(R.id.passwordInput);
        Button loginButton = findViewById(R.id.loginButton);
        Button createAccountButton = findViewById(R.id.createAccountButton);

        loginButton.setOnClickListener(v -> attemptLogin());
        createAccountButton.setOnClickListener(v -> attemptCreateAccount());
    }

    private void attemptLogin() {
        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();

        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Please enter both a username and password.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (databaseHelper.checkUserCredentials(username, password)) {
            goToInventoryScreen(username);
        } else {
            Toast.makeText(this, "Incorrect username or password.", Toast.LENGTH_SHORT).show();
        }
    }

    private void attemptCreateAccount() {
        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();

        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Please enter both a username and password.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (databaseHelper.checkUsernameExists(username)) {
            Toast.makeText(this, "That username is already taken.", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean success = databaseHelper.createUser(username, password);
        if (success) {
            Toast.makeText(this, "Account created successfully.", Toast.LENGTH_SHORT).show();
            goToInventoryScreen(username);
        } else {
            Toast.makeText(this, "Something went wrong creating the account.", Toast.LENGTH_SHORT).show();
        }
    }

    private void goToInventoryScreen(String username) {
        Intent intent = new Intent(MainActivity.this, InventoryActivity.class);
        intent.putExtra("LOGGED_IN_USER", username);
        startActivity(intent);
        finish();
    }
}