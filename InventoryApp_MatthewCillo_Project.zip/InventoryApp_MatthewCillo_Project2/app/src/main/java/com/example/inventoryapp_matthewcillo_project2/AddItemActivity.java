package com.example.inventoryapp_matthewcillo_project2;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

// Screen used both to add a brand new inventory item and to edit an existing one.
// If an item ID is passed in through the Intent, this screen loads and edits that item.
// If no ID is passed in, it behaves as an "add new item" screen instead.
// Whenever an item is saved with a quantity of zero, this screen also attempts
// to send a low-stock text alert, but only if the user has granted SMS permission.
public class AddItemActivity extends AppCompatActivity {

    public static final String EXTRA_ITEM_ID = "EXTRA_ITEM_ID";
    private static final long NO_ITEM_ID = -1L;

    // Placeholder alert number used for testing in the Android Emulator.
    // In a real release build, this would come from a saved user setting instead of being fixed.
    private static final String ALERT_PHONE_NUMBER = "5555550101";

    private EditText itemNameInput;
    private EditText itemQuantityInput;
    private DatabaseHelper databaseHelper;
    private long editingItemId = NO_ITEM_ID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        databaseHelper = new DatabaseHelper(this);

        TextView titleText = findViewById(R.id.addItemTitle);
        itemNameInput = findViewById(R.id.itemNameInput);
        itemQuantityInput = findViewById(R.id.itemQuantityInput);
        Button saveButton = findViewById(R.id.saveItemButton);

        editingItemId = getIntent().getLongExtra(EXTRA_ITEM_ID, NO_ITEM_ID);

        if (editingItemId != NO_ITEM_ID) {
            titleText.setText("Edit Item");
            loadExistingItem();
        } else {
            titleText.setText("Add Item");
        }

        saveButton.setOnClickListener(v -> saveItem());
    }

    // Loads the existing item's name and quantity into the input fields for editing.
    private void loadExistingItem() {
        InventoryItem item = databaseHelper.getItemById(editingItemId);
        if (item != null) {
            itemNameInput.setText(item.getName());
            itemQuantityInput.setText(String.valueOf(item.getQuantity()));
        }
    }

    // Validates the entered name and quantity, then either inserts a new item
    // or updates the existing one. If the saved quantity is zero, this also
    // attempts to send a low-stock SMS alert.
    private void saveItem() {
        String name = itemNameInput.getText().toString().trim();
        String quantityText = itemQuantityInput.getText().toString().trim();

        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(quantityText)) {
            Toast.makeText(this, "Please enter a name and quantity.", Toast.LENGTH_SHORT).show();
            return;
        }

        int quantity;
        try {
            quantity = Integer.parseInt(quantityText);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Quantity must be a whole number.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (editingItemId != NO_ITEM_ID) {
            databaseHelper.updateItem(editingItemId, name, quantity);
        } else {
            databaseHelper.addItem(name, quantity);
        }

        if (quantity == 0) {
            sendLowStockAlertIfPermitted(name);
        }

        finish();
    }

    // Sends a text alert for the given item if SMS permission has been granted.
    // If permission was denied, this quietly does nothing and the rest of the app
    // continues to work as normal, matching the required fallback behavior.
    private void sendLowStockAlertIfPermitted(String itemName) {
        boolean permissionGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;

        if (!permissionGranted) {
            return;
        }

        try {
            String message = itemName + " is out of stock and needs to be restocked.";
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(ALERT_PHONE_NUMBER, null, message, null, null);
            Toast.makeText(this, "Low stock alert sent for " + itemName, Toast.LENGTH_SHORT).show();
        } catch (SecurityException e) {
            Toast.makeText(this, "Could not send SMS alert.", Toast.LENGTH_SHORT).show();
        }
    }
}