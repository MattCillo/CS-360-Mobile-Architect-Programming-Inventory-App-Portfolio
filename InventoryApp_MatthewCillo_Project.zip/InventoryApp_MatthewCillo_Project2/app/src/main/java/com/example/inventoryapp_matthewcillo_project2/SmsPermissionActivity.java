package com.example.inventoryapp_matthewcillo_project2;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class SmsPermissionActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);
    }
}
