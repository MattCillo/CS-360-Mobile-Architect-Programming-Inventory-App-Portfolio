package com.example.inventoryapp_matthewcillo_project2;

// Simple data container representing one row of inventory: its database ID,
// its display name, and its current quantity in stock.
public class InventoryItem {

    private final long id;
    private final String name;
    private final int quantity;

    public InventoryItem(long id, String name, int quantity) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getQuantity() {
        return quantity;
    }
}