package com.example.inventoryapp_matthewcillo_project2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

// Displays the list of inventory items in a grid-style layout.
// Each row shows the item name, quantity, and buttons to edit or delete it.
public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ItemViewHolder> {

    // Callback interface so InventoryActivity can react when a row's buttons are tapped.
    public interface OnItemActionListener {
        void onEditClicked(InventoryItem item);
        void onDeleteClicked(InventoryItem item);
    }

    private List<InventoryItem> itemList;
    private final OnItemActionListener listener;

    public InventoryAdapter(List<InventoryItem> itemList, OnItemActionListener listener) {
        this.itemList = itemList;
        this.listener = listener;
    }

    // Replaces the current list with a fresh one and redraws the grid.
    public void updateItems(List<InventoryItem> newItems) {
        this.itemList = newItems;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_row, parent, false);
        return new ItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        InventoryItem item = itemList.get(position);
        holder.nameText.setText(item.getName());
        holder.quantityText.setText(String.valueOf(item.getQuantity()));

        holder.editButton.setOnClickListener(v -> listener.onEditClicked(item));
        holder.deleteButton.setOnClickListener(v -> listener.onDeleteClicked(item));
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    // Holds references to each row's views so they don't need to be looked up repeatedly.
    static class ItemViewHolder extends RecyclerView.ViewHolder {
        TextView nameText;
        TextView quantityText;
        Button editButton;
        Button deleteButton;

        ItemViewHolder(View itemView) {
            super(itemView);
            nameText = itemView.findViewById(R.id.itemNameText);
            quantityText = itemView.findViewById(R.id.itemQuantityText);
            editButton = itemView.findViewById(R.id.editItemButton);
            deleteButton = itemView.findViewById(R.id.deleteItemButton);
        }
    }
}